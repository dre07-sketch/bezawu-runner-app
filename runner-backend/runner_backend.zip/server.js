const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');

const app = express();

// 1. Security Middleware
// app.use(helmet()); // Sets various HTTP headers for security
app.use(cors()); // Enable CORS
app.use(express.json({ limit: '10kb' })); // Limit body size to prevent DoS
app.use('/uploads', express.static('uploads')); // Serve uploaded files

// DEBUG LOGGING
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// 2. Rate Limiting (Brute Force Protection)
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 2000, // Limit each IP to 2000 requests per windowMs (Increased for Dev)
    message: 'Too many requests from this IP, please try again later.'
});
// app.use('/api', limiter); // Globally commented out for dev

// const authLimiter = rateLimit({
//     windowMs: 60 * 60 * 1000, // 1 hour
//     max: 100, // Max 100 login/signup attempts per hour (Increased for Dev)
//     message: 'Too many login attempts, please try again later.'
// });
// app.use('/api/auth/login', authLimiter);

// 3. Routes
console.log('Mounting /api/auth routes...');
app.use('/api/auth', authRoutes);
console.log('Mounted /api/auth routes.');
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/cart', require('./routes/cart'));
app.use('/api/user', require('./routes/user'));
app.use('/api/family', require('./routes/family'));
app.use('/api/chat', require('./routes/chat'));
app.use('/api/bundles', require('./routes/bundles'));
app.use('/api/supermarkets', require('./routes/supermarkets'));
app.use('/api/feedback', require('./routes/feedback'));
app.use('/api/stories', require('./routes/stories'));
app.use('/api/ads', require('./routes/ads'));
app.use('/api/gifts', require('./routes/gifts'));



// 4. Global Error Handler
app.use((req, res, next) => {
    console.log('!!! 404 FALLBACK MATCHED !!! URL:', req.url);
    res.status(404).json({ message: 'Resource not found fallthrough' });
});

app.use((err, req, res, next) => {
    console.error('Global Error Handler:', err.stack);
    // Handle Multer errors specifically if needed, or just send message
    if (err.message === 'Only images are allowed') {
        return res.status(400).json({ status: 'error', message: err.message });
    }
    res.status(500).json({ status: 'error', message: err.message || 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT} and accessible via LAN at ${require('os').networkInterfaces()['WiFi']?.[1]?.address || 'CHECK_IP_CONFIG'}`);
});
