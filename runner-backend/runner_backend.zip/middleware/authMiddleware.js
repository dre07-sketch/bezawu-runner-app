const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_key_change_this';

const verifyToken = async (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'No token provided' });

    try {
        const decoded = jwt.verify(token.split(' ')[1], JWT_SECRET);
        req.user = decoded;

        // VERIFY USER EXISTENCE IN DB to prevent FK violations later
        if (decoded.role === 'customer') {
            const userCheck = await pool.query('SELECT id FROM customers WHERE id = $1', [decoded.id]);
            if (userCheck.rows.length === 0) {
                return res.status(401).json({ message: 'User no longer exists. Please login again.' });
            }
        }
        // Optional: Add checks for other roles if needed

        next();
    } catch (err) {
        console.error('Token verification failed:', err.message);
        return res.status(401).json({ message: 'Unauthorized' });
    }
};

module.exports = { verifyToken, pool };
