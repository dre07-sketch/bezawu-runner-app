const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const { pool, verifyToken } = require('../middleware/authMiddleware');

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_key_change_this'; // Still need secret? Actually no, verifyToken handles it. But let's check if we use it elsewhere. No.

// Configure Multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = 'uploads/';
        // Create dir if not exists
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        // Unique filename: user_id + timestamp + extension
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        console.log('Multer processing file:', file.originalname, 'MIME:', file.mimetype);

        const validMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        const validExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
        const ext = path.extname(file.originalname).toLowerCase();

        if (validMimeTypes.includes(file.mimetype) || (file.mimetype === 'application/octet-stream' && validExtensions.includes(ext))) {
            cb(null, true);
        } else {
            console.log('Rejected file - MIME:', file.mimetype, 'Ext:', ext);
            cb(new Error('Only images are allowed'));
        }
    }
});


// GET User Profile
router.get('/', verifyToken, async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT id, name, phone, email, loyalty_points, is_fasting_mode, wallet_balance, profile_picture, default_car_plate, default_car_model, default_car_color, default_car_year, default_car_image, is_age_verified FROM customers WHERE id = $1',
            [req.user.id]
        );

        if (result.rows.length === 0) return res.status(404).json({ message: 'User not found' });

        let user = result.rows[0];

        // Append full URL to images if they exist and are relative paths
        // Assuming server serves 'uploads' statically
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;

        if (user.profile_picture && !user.profile_picture.startsWith('http')) {
            user.profile_picture = baseUrl + user.profile_picture;
        }
        if (user.default_car_image && !user.default_car_image.startsWith('http')) {
            user.default_car_image = baseUrl + user.default_car_image;
        }

        res.json(user);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// UPDATE User Profile (supports multipart/form-data)
router.put('/', verifyToken, upload.fields([{ name: 'profile_picture', maxCount: 1 }, { name: 'car_image', maxCount: 1 }, { name: 'id_card_image', maxCount: 1 }]), async (req, res) => {
    // req.body contains text fields
    // req.files contains uploaded files

    let { name, email, default_car_plate, default_car_model, default_car_color, default_car_year, is_fasting_mode } = req.body;

    // Construct values to update
    // We only update fields that are provided
    // Ideally we should fetch current user to merge, but simple SQL update works if we pass everything usually.
    // However, for files, we only want to update if a new file comes.

    try {
        console.log('Update User Request Body:', req.body);
        console.log('Update User Files:', req.files); // Might be undefined

        // 1. Fetch current user to preserve existing image paths if not updated
        const currentUserRes = await pool.query('SELECT profile_picture, default_car_image, id_card_url FROM customers WHERE id = $1', [req.user.id]);

        if (currentUserRes.rows.length === 0) {
            console.log('User not found during update:', req.user.id);
            return res.status(404).json({ message: 'User not found' });
        }

        const currentUser = currentUserRes.rows[0];

        let profilePicPath = currentUser.profile_picture;
        let carImagePath = currentUser.default_car_image;
        let idCardPath = currentUser.id_card_url;

        const files = req.files || {}; // Safe access

        if (files['profile_picture']) {
            profilePicPath = files['profile_picture'][0].filename;
        }
        if (files['car_image']) {
            carImagePath = files['car_image'][0].filename;
        }
        if (files['id_card_image']) {
            idCardPath = files['id_card_image'][0].filename;
        }

        // Handle Integer conversion safely
        let yearInt = null;
        if (default_car_year && !isNaN(parseInt(default_car_year))) {
            yearInt = parseInt(default_car_year);
        }

        const result = await pool.query(
            `UPDATE customers 
             SET name = COALESCE($1, name), 
                 email = COALESCE($2, email), 
                 profile_picture = $3, 
                 default_car_plate = COALESCE($4, default_car_plate), 
                 default_car_model = COALESCE($5, default_car_model), 
                 default_car_color = COALESCE($6, default_car_color),
                 default_car_year = COALESCE($7, default_car_year),
                 default_car_image = $8,
                 is_fasting_mode = COALESCE($10, is_fasting_mode),
                 id_card_url = $11,
                 updated_at = NOW()
             WHERE id = $9
             RETURNING id, name, phone, email, loyalty_points, is_fasting_mode, profile_picture, default_car_plate, default_car_model, default_car_color, default_car_year, default_car_image, is_age_verified`,
            [
                name || null,
                email || null,
                profilePicPath,
                default_car_plate || null,
                default_car_model || null,
                default_car_color || null,
                yearInt,
                carImagePath,
                req.user.id,
                is_fasting_mode, // $10 (boolean check handled by Postgres if string 'true'/'false')
                idCardPath // $11
            ]
        );

        // Format response URLs
        let updatedUser = result.rows[0];
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
        if (updatedUser.profile_picture && !updatedUser.profile_picture.startsWith('http')) {
            updatedUser.profile_picture = baseUrl + updatedUser.profile_picture;
        }
        if (updatedUser.default_car_image && !updatedUser.default_car_image.startsWith('http')) {
            updatedUser.default_car_image = baseUrl + updatedUser.default_car_image;
        }

        res.json(updatedUser);
    } catch (err) {
        console.error('Error updating user profile:', err); // Should show up in server logs
        res.status(500).json({ message: 'Server error updating profile', error: err.toString() });
    }
});

// Feature 30: Wallet Topup
router.post('/wallet/topup', verifyToken, async (req, res) => {
    const { amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

    try {
        const result = await pool.query(
            'UPDATE customers SET wallet_balance = COALESCE(wallet_balance, 0) + $1 WHERE id = $2 RETURNING wallet_balance',
            [amount, req.user.id]
        );
        res.json({ balance: result.rows[0].wallet_balance, message: 'Topup successful' });
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
