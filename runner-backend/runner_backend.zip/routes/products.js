const express = require('express');
const router = express.Router();
require('dotenv').config();

const { pool } = require('../middleware/authMiddleware');


// Get all products (with inventory info for a specific branch if provided)
router.get('/', async (req, res) => {
    const { branch_id } = req.query; // Optional: filter by branch stock
    console.log(`GET /products params: branch_id=${branch_id}`);

    try {
        let query;
        let params = [];

        if (branch_id) {
            // Filter directly by products.branch_id as requested
            query = `
                SELECT p.*, c.name as category_name, b.name as branch_name, s.name as supermarket_name
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN branches b ON p.branch_id = b.id
                LEFT JOIN supermarkets s ON b.supermarket_id = s.id
                WHERE 1=1 AND p.branch_id = $1
            `;
            params.push(branch_id);
        } else {
            // Fetch all if no branch specified
            query = `
                SELECT p.*, c.name as category_name, b.name as branch_name, s.name as supermarket_name
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN branches b ON p.branch_id = b.id
                LEFT JOIN supermarkets s ON b.supermarket_id = s.id
                WHERE 1=1
            `;
        }

        // Apply Fasting Filter
        // Apply Fasting Filter
        if (req.query.fasting === 'true') {
            query += ` AND p.is_fasting_friendly = TRUE`;
        }

        // Apply Flash Deal Filter (Feature 15)
        if (req.query.flash === 'true') {
            query += ` AND p.is_flash_deal = TRUE`;
        }

        const result = await pool.query(query, params);

        // Fix Image URLs dynamically
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
        const products = result.rows.map(p => {
            if (p.image_url && !p.image_url.startsWith('http') && !p.image_url.startsWith('assets')) {
                p.image_url = baseUrl + p.image_url;
            }
            return p;
        });

        res.json(products);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
