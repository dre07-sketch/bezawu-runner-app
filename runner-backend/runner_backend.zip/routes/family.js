const express = require('express');
const router = express.Router();
const { verifyToken, pool } = require('../middleware/authMiddleware');

// Generate a random 6-character code
function generateCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// Get Family Info
router.get('/', verifyToken, async (req, res) => {
    try {
        const userId = req.user.id;

        // Get user's family ID
        const userRes = await pool.query('SELECT family_group_id FROM customers WHERE id = $1', [userId]);
        const familyId = userRes.rows[0]?.family_group_id;

        if (!familyId) {
            return res.status(200).json(null); // No family
        }

        // Get Family Details and Members
        const familyRes = await pool.query('SELECT * FROM family_groups WHERE id = $1', [familyId]);
        const membersRes = await pool.query('SELECT id, name, profile_picture FROM customers WHERE family_group_id = $1', [familyId]);

        res.json({
            ...familyRes.rows[0],
            members: membersRes.rows
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create Family
router.post('/create', verifyToken, async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const userId = req.user.id;
        const { groupName } = req.body;
        const code = generateCode();

        // Create Group
        const insertRes = await client.query(
            'INSERT INTO family_groups (name, code) VALUES ($1, $2) RETURNING id',
            [groupName || 'My Family', code]
        );
        const familyId = insertRes.rows[0].id;

        // Add User to Group
        await client.query('UPDATE customers SET family_group_id = $1 WHERE id = $2', [familyId, userId]);

        await client.query('COMMIT');
        res.json({ id: familyId, name: groupName, code: code });

    } catch (err) {
        await client.query('ROLLBACK');
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    } finally {
        client.release();
    }
});

// Join Family
router.post('/join', verifyToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { code } = req.body;

        // Find Group
        const groupRes = await pool.query('SELECT id FROM family_groups WHERE code = $1', [code]);
        if (groupRes.rows.length === 0) {
            return res.status(404).json({ message: 'Invalid family code' });
        }
        const familyId = groupRes.rows[0].id;

        // Update User
        await pool.query('UPDATE customers SET family_group_id = $1 WHERE id = $2', [familyId, userId]);

        res.json({ message: 'Joined family successfully', familyId });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Leave Family
router.post('/leave', verifyToken, async (req, res) => {
    try {
        const userId = req.user.id;
        await pool.query('UPDATE customers SET family_group_id = NULL WHERE id = $1', [userId]);
        res.json({ message: 'Left family successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
