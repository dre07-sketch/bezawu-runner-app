const express = require('express');
const router = express.Router();
const { pool } = require('../middleware/authMiddleware'); // Re-using pool from middleware setup
require('dotenv').config();

// Get Active Ads
router.get('/', async (req, res) => {
    try {
        const result = await pool.query(
            "SELECT * FROM ads WHERE is_active = true ORDER BY created_at DESC"
        );

        // Ensure URLs are valid (match uploads logic)
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
        const items = result.rows.map(item => {
            if (item.media_url && !item.media_url.startsWith('http')) {
                // 1. Clean path
                let cleanPath = item.media_url;
                if (cleanPath.startsWith('/')) cleanPath = cleanPath.substring(1);
                if (cleanPath.startsWith('uploads/')) cleanPath = cleanPath.substring(8);

                // 2. Attach Base
                item.media_url = baseUrl + cleanPath;
            }
            return item;
        });

        res.json(items);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error retrieving ads' });
    }
});

module.exports = router;
