const express = require('express');
const router = express.Router();
require('dotenv').config();
const { pool, verifyToken } = require('../middleware/authMiddleware');

// Get Messages for Order
router.get('/:orderId', verifyToken, async (req, res) => {
    try {
        const { orderId } = req.params;
        const result = await pool.query(
            'SELECT * FROM order_chats WHERE order_id = $1 ORDER BY created_at ASC',
            [orderId]
        );
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Send Message
router.post('/:orderId', verifyToken, async (req, res) => {
    try {
        const { orderId } = req.params;
        const { message } = req.body;
        // const userId = req.user.id; // Not used in current schema? Or maybe we should? 
        // Schema has NO sender_id column listed. Only sender_type.

        const senderType = 'CUSTOMER'; // Must be uppercase as per DB constraint

        // Insert
        const r = await pool.query(
            'INSERT INTO order_chats (order_id, sender_type, message) VALUES ($1, $2, $3) RETURNING *',
            [orderId, senderType, message]
        );

        res.json(r.rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
