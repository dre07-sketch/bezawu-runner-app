const express = require('express');
const router = express.Router();
require('dotenv').config();

const { verifyToken, pool } = require('../middleware/authMiddleware');

// Get Cart (Bundles & Products)
router.get('/', verifyToken, async (req, res) => {
    try {
        const userId = req.user.id;

        // Check if user is in a family
        const userRes = await pool.query('SELECT family_group_id FROM customers WHERE id = $1', [userId]);
        const familyId = userRes.rows[0]?.family_group_id;

        let whereClause;
        let params;

        if (familyId) {
            whereClause = `c.customer_id IN (SELECT id FROM customers WHERE family_group_id = $1)`;
            params = [familyId];
        } else {
            whereClause = `c.customer_id = $1`;
            params = [userId];
        }

        const query = `
            SELECT 
                c.id, c.quantity, c.customer_id, c.created_at, c.branch_id,
                cust.name as added_by_name,
                c.product_id, p.name as product_name, p.price as product_price, p.image_url as product_image, cat.name as category_name,
                c.bundle_id, b.name as bundle_name, b.price as bundle_price, b.image_url as bundle_image,
                COALESCE(br.name, br_manual.name) as branch_name, 
                COALESCE(br.map_pin, br_manual.map_pin) as branch_map_pin
            FROM cart_items c
            LEFT JOIN customers cust ON c.customer_id = cust.id
            LEFT JOIN products p ON c.product_id = p.id
            LEFT JOIN categories cat ON p.category_id = cat.id
            LEFT JOIN bundles b ON c.bundle_id = b.id
            LEFT JOIN branches br ON b.branch_id = br.id
            LEFT JOIN branches br_manual ON c.branch_id = br_manual.id
            WHERE ${whereClause}
            ORDER BY c.created_at DESC
        `;

        const result = await pool.query(query, params);

        // Fix Image URLs dynamically (Same as Products)
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
        const items = result.rows.map(i => {
            if (i.product_image && !i.product_image.startsWith('http') && !i.product_image.startsWith('assets')) {
                i.product_image = baseUrl + i.product_image;
            }
            if (i.bundle_image && !i.bundle_image.startsWith('http')) {
                i.bundle_image = baseUrl + i.bundle_image;
            }
            return i;
        });

        res.json(items);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error fetching cart' });
    }
});

router.post('/', verifyToken, async (req, res) => {
    const { product_id, bundle_id, quantity, branch_id } = req.body;
    const qty = quantity || 1;

    if (!product_id && !bundle_id) {
        return res.status(400).json({ message: 'Product or Bundle ID required' });
    }

    try {
        const userId = req.user.id;

        // For ADDING, we verify against FAMILY Items too to allow incrementing existing family item?
        // Or do we add a NEW row for ME?
        // If "Shared", maybe I update existing row even if not mine?
        // Simplifying: I update MY row. If I want to increment someone else's, it's complex.
        // Let's stick to: "Shared View". I add MY items. They see it.
        // If they add same item -> 2 rows?
        // Ideally 1 row.
        // Let's Query if ANYONE in family has this item.

        // Check family
        const userRes = await pool.query('SELECT family_group_id FROM customers WHERE id = $1', [userId]);
        const familyId = userRes.rows[0]?.family_group_id;

        let checkQuery;
        let checkParams;
        if (familyId) {
            if (product_id) {
                checkQuery = `SELECT * FROM cart_items WHERE product_id = $1 AND customer_id IN (SELECT id FROM customers WHERE family_group_id = $2)`;
                checkParams = [product_id, familyId];
            } else {
                checkQuery = `SELECT * FROM cart_items WHERE bundle_id = $1 AND customer_id IN (SELECT id FROM customers WHERE family_group_id = $2)`;
                checkParams = [bundle_id, familyId];
            }
        } else {
            if (product_id) {
                checkQuery = `SELECT * FROM cart_items WHERE product_id = $1 AND customer_id = $2`;
                checkParams = [product_id, userId];
            } else {
                checkQuery = `SELECT * FROM cart_items WHERE bundle_id = $1 AND customer_id = $2`;
                checkParams = [bundle_id, userId];
            }
        }

        // Also check branch_id if relevant... skipping complex branch logic for brevity in shared cart.

        const existing = await pool.query(checkQuery, checkParams);

        if (existing.rows.length > 0) {
            // Update quantity of FIRST matching item (even if not mine)
            const newQty = existing.rows[0].quantity + qty;
            if (newQty <= 0) {
                await pool.query('DELETE FROM cart_items WHERE id = $1', [existing.rows[0].id]);
            } else {
                await pool.query('UPDATE cart_items SET quantity = $1 WHERE id = $2', [newQty, existing.rows[0].id]);
            }
        } else {
            // Insert new item linked to ME
            if (qty > 0) {
                const col = product_id ? 'product_id' : 'bundle_id';
                const val = product_id || bundle_id;
                await pool.query(
                    `INSERT INTO cart_items (customer_id, ${col}, quantity, branch_id) VALUES ($1, $2, $3, $4)`,
                    [userId, val, qty, branch_id]
                );
            }
        }
        res.json({ message: 'Cart updated' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error updating cart' });
    }
});

router.delete('/:id', verifyToken, async (req, res) => {
    const targetId = req.params.id; // Product ID or Bundle ID passed from frontend
    const userId = req.user.id;

    try {
        // Find if user is in family
        const userRes = await pool.query('SELECT family_group_id FROM customers WHERE id = $1', [userId]);
        const familyId = userRes.rows[0]?.family_group_id;

        let condition;
        let params = [targetId];

        if (familyId) {
            condition = `customer_id IN (SELECT id FROM customers WHERE family_group_id = $2)`;
            params.push(familyId);
        } else {
            condition = `customer_id = $2`;
            params.push(userId);
        }

        // Try deleting by product_id
        const res1 = await pool.query(
            `DELETE FROM cart_items WHERE product_id = $1 AND ${condition}`,
            params
        );

        if (res1.rowCount === 0) {
            await pool.query(
                `DELETE FROM cart_items WHERE bundle_id = $1 AND ${condition}`,
                params
            );
        }

        res.json({ message: 'Item removed' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error removing item' });
    }
});

router.put('/:id/policy', verifyToken, async (req, res) => {
    const { policy } = req.body;
    try {
        await pool.query('UPDATE cart_items SET substitution_policy = $1 WHERE id = $2', [policy, req.params.id]);
        // Note: Assuming user owns item or is in family. 
        res.json({ message: 'Policy updated' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error updating policy' });
    }
});

module.exports = router;
