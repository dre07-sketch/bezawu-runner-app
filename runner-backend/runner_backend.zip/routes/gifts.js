const express = require('express');
const router = express.Router();
const { verifyToken, pool } = require('../middleware/authMiddleware');

// Get All Gifts (Fetch Products in 'Gifts' Category)
router.get('/', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT p.* 
            FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE c.name = 'Gifts'
            ORDER BY p.price ASC
        `);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error retrieving gifts' });
    }
});

// Get My Received Gifts
router.get('/my-received', verifyToken, async (req, res) => {
    try {
        // Find gifts where recipient_phone matches user's phone
        const userRes = await pool.query('SELECT phone FROM customers WHERE id = $1', [req.user.id]);
        if (userRes.rows.length === 0) return res.status(404).json({ message: 'User not found' });

        const userPhone = userRes.rows[0].phone;

        const giftsRes = await pool.query(`
            SELECT o.id, o.gift_message, o.created_at, o.status,
                   b.name as branch_name,
                   json_agg(json_build_object('name', p.name, 'image_url', p.image_url)) as items
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            LEFT JOIN products p ON oi.product_id = p.id
            LEFT JOIN branches b ON o.branch_id = b.id
            WHERE RIGHT(REPLACE(o.recipient_phone, ' ', ''), 9) = RIGHT(REPLACE($1, ' ', ''), 9) AND o.is_gift = true
            GROUP BY o.id, b.name
            ORDER BY o.created_at DESC
        `, [userPhone]);

        res.json(giftsRes.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error retrieving received gifts' });
    }
});

module.exports = router;
