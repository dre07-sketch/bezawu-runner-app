const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const { verifyToken } = require('../middleware/authMiddleware');
require('dotenv').config();

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// GET /api/stories (With Likes/Comments Counts & User Status)
// GET /api/stories (With Likes/Comments Counts & User Status)
router.get('/', async (req, res) => {
    try {
        let userId = null;
        const authHeader = req.headers.authorization;
        if (authHeader) {
            const token = authHeader.split(' ')[1];
            try {
                const jwt = require('jsonwebtoken');
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                userId = decoded.id;
            } catch (e) { /* Ignore invalid token */ }
        }

        let query = `
            SELECT s.*, 
            b.name as branch_name,
            sp.name as supermarket_name,
            sp.logo as supermarket_logo,
            (SELECT COUNT(*) FROM story_comments_and_likes WHERE story_id = s.id AND type = 'like') as real_likes_count,
            (SELECT COUNT(*) FROM story_comments_and_likes WHERE story_id = s.id AND type = 'comment') as real_comments_count
        `;

        if (userId) {
            // We need to be careful about SQL injection, but userId comes from JWT.
            // Using parameterized query is hard with variable columns unless we handle it well.
            // Since userId is trusted from JWT, string interpolation is "okay" but risky.
            // Better: Use parameters. But we construct query string.
            // Let's assume userId is safe (it's from our signed token).
            query += `, (EXISTS(SELECT 1 FROM story_comments_and_likes WHERE story_id = s.id AND user_id = '${userId}' AND type = 'like')) as is_liked`;
        } else {
            query += `, false as is_liked`;
        }

        query += `
            FROM stories s
            LEFT JOIN branches b ON s.branch_id = b.id
            LEFT JOIN supermarkets sp ON (s.supermarket_id = sp.id OR b.supermarket_id = sp.id)
            WHERE s.is_active = true
            ORDER BY s.created_at DESC
        `;

        const result = await pool.query(query);

        // Map results to client format
        const stories = result.rows.map(story => {
            // Construct Display Name (Vendor)
            let displayName = 'Bezaw Partner';
            if (story.supermarket_name) {
                displayName = story.supermarket_name;
                if (story.branch_name && story.branch_name !== story.supermarket_name) {
                    displayName += ` (${story.branch_name})`;
                }
            } else if (story.branch_name) {
                displayName = story.branch_name;
            }

            // Fix for missing local files
            const baseUrl = `${req.protocol}://${req.get('host')}`;
            let videoUrl = story.video_url;
            if (videoUrl && videoUrl.startsWith('/uploads')) {
                videoUrl = `${baseUrl}${videoUrl}`;
            }

            let thumbnailUrl = story.thumbnail_url;
            if (thumbnailUrl && thumbnailUrl.startsWith('/uploads')) {
                thumbnailUrl = `${baseUrl}${thumbnailUrl}`;
            }

            return {
                ...story,
                video_url: videoUrl,
                thumbnail_url: thumbnailUrl,
                vendor_name: displayName,
                likes_count: parseInt(story.real_likes_count || 0),
                comments_count: parseInt(story.real_comments_count || 0)
            };
        });

        res.json(stories);
    } catch (err) {
        console.error("Error fetching stories:", err);
        res.status(500).json({ error: 'Server error fetching stories' });
    }
});

// POST /api/stories/:id/like (Toggle Like)
router.post('/:id/like', verifyToken, async (req, res) => {
    const storyId = req.params.id;
    const userId = req.user.id;
    const userName = req.user.name || 'User';

    try {
        const checkRes = await pool.query(
            "SELECT id FROM story_comments_and_likes WHERE story_id = $1 AND user_id = $2 AND type = 'like'",
            [storyId, userId]
        );

        if (checkRes.rows.length > 0) {
            // Unlike
            await pool.query("DELETE FROM story_comments_and_likes WHERE id = $1", [checkRes.rows[0].id]);
            return res.json({ status: 'unliked' });
        } else {
            // Like
            await pool.query(
                "INSERT INTO story_comments_and_likes (story_id, user_id, user_name, type) VALUES ($1, $2, $3, 'like')",
                [storyId, userId, userName]
            );
            return res.json({ status: 'liked' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
});

// POST /api/stories/:id/comment (Add Comment)
router.post('/:id/comment', verifyToken, async (req, res) => {
    const storyId = req.params.id;
    const userId = req.user.id;
    const { text } = req.body;

    let userName = req.user.name || 'User';
    if (userName === 'User') {
        const uRes = await pool.query('SELECT name FROM customers WHERE id = $1', [userId]);
        if (uRes.rows.length > 0) userName = uRes.rows[0].name;
    }

    try {
        const newComment = await pool.query(
            "INSERT INTO story_comments_and_likes (story_id, user_id, user_name, type, content) VALUES ($1, $2, $3, 'comment', $4) RETURNING *",
            [storyId, userId, userName, text]
        );
        res.json(newComment.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
});

// GET /api/stories/:id/comments (Fetch Comments)
router.get('/:id/comments', async (req, res) => {
    const storyId = req.params.id;
    try {
        const comments = await pool.query(
            "SELECT * FROM story_comments_and_likes WHERE story_id = $1 AND type = 'comment' ORDER BY created_at DESC",
            [storyId]
        );
        res.json(comments.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
