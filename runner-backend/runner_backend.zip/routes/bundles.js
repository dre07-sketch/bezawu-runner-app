const express = require('express');
const router = express.Router();
const { pool } = require('../middleware/authMiddleware'); // Re-use pool

// GET /api/bundles - Fetch all active bundles
router.get('/', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT 
                b.id, 
                b.name, 
                b.description, 
                b.price, 
                b.image_url,
                b.branch_id,
                br.name as branch_name,
                (
                    SELECT json_agg(json_build_object(
                        'product_id', p.id,
                        'name', p.name,
                        'quantity', bi.quantity,
                        'image_url', p.image_url,
                        'price_per_unit', p.price
                    ))
                    FROM bundle_items bi
                    JOIN products p ON bi.product_id = p.id
                    WHERE bi.bundle_id = b.id
                ) as items
            FROM bundles b
            JOIN branches br ON b.branch_id = br.id
            WHERE b.is_active = true
            ${req.query.branch_id ? `AND b.branch_id = '${req.query.branch_id}'` : ''}
        `);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// GET /api/bundles/:id - Fetch single bundle details
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query(`
            SELECT 
                b.id, 
                b.name, 
                b.description, 
                b.price, 
                b.image_url,
                b.branch_id,
                br.name as branch_name,
                (
                    SELECT json_agg(json_build_object(
                        'product_id', p.id,
                        'name', p.name,
                        'quantity', bi.quantity,
                        'image_url', p.image_url,
                        'price_per_unit', p.price
                    ))
                    FROM bundle_items bi
                    JOIN products p ON bi.product_id = p.id
                    WHERE bi.bundle_id = b.id
                ) as items
            FROM bundles b
            JOIN branches br ON b.branch_id = br.id
            WHERE b.id = $1
        `, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Bundle not found' });
        }

        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
