const express = require('express');
const router = express.Router();
const { verifyToken, pool } = require('../middleware/authMiddleware');

// POST /api/feedback
router.post('/', verifyToken, async (req, res) => {
    const { order_id, rating, comment, branch_id } = req.body;
    const customer_id = req.user.id; // Get from token

    if (!order_id || !rating || !branch_id) {
        return res.status(400).json({ status: 'error', message: 'Missing required fields: order_id, rating, branch_id' });
    }

    try {
        // Use the pool imported from middleware (or authMiddleware)
        // const client = await pool.connect(); -> pool.query handles checkout/release automatically usually, but let's stick to pattern

        // Check if feedback already exists for this order
        const existingCheck = await pool.query('SELECT id FROM feedback WHERE order_id = $1', [order_id]);
        if (existingCheck.rows.length > 0) {
            return res.status(400).json({ status: 'error', message: 'Feedback already submitted for this order' });
        }

        const result = await pool.query(
            `INSERT INTO feedback (order_id, rating, comment, branch_id, customer_id) 
             VALUES ($1, $2, $3, $4, $5) 
             RETURNING *`,
            [order_id, rating, comment, branch_id, customer_id]
        );

        res.status(201).json({ status: 'success', data: result.rows[0] });

    } catch (err) {
        console.error('Error submitting feedback:', err);
        res.status(500).json({ status: 'error', message: 'Internal server error' });
    }
});

module.exports = router;
