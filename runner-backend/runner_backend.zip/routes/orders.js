const express = require('express');
const router = express.Router();
require('dotenv').config();

const { verifyToken, pool } = require('../middleware/authMiddleware');

// Employee View (Protected - Runner/Manager)
router.get('/employee-view', verifyToken, async (req, res) => {
    try {
        console.log('GET /employee-view called');
        console.log('User:', req.user);
        const branchId = req.user.branch_id;
        console.log('Fetching orders for branch:', branchId);

        if (!branchId) {
            console.error("Branch ID missing in token");
            return res.status(400).json({ message: "Branch ID missing" });
        }

        const query = `
            SELECT o.id, o.status, o.total_price, o.created_at, o.scheduled_pickup_time, o.order_note,
                   o.car_model, o.car_plate, o.car_color,
                   o.is_gift, o.recipient_phone, o.gift_message,
                   o.vehicle_type, o.vehicle_plate, o.vehicle_color,
                   u.name as customer_name,
                   u.default_car_image,
                   json_agg(json_build_object(
                       'name', p.name, 
                       'quantity', oi.quantity,
                       'substitutionPolicy', 'Best Match'
                   )) as items
            FROM orders o
            LEFT JOIN customers u ON o.customer_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE o.branch_id = $1 -- Filter by Branch
            GROUP BY o.id, u.name, u.default_car_image
            ORDER BY o.created_at DESC
            LIMIT 100
        `;
        const result = await pool.query(query, [branchId]);

        // Map to Frontend Interface
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;

        const orders = result.rows.map(row => ({
            id: row.id,
            customerName: row.customer_name || 'Guest',
            totalPrice: row.total_price,
            status: row.status,
            createdAt: row.created_at,
            items: row.items,
            carProfile: {
                model: (row.vehicle_type && row.vehicle_type !== 'private')
                    ? (row.vehicle_type.toUpperCase() + (row.car_model ? ` (${row.car_model})` : ''))
                    : (row.car_model || 'Unknown'),
                color: row.vehicle_color || row.car_color || 'Unknown',
                plateNumber: row.vehicle_plate || row.car_plate || 'Unknown',
                image: row.default_car_image ? (row.default_car_image.startsWith('http') ? row.default_car_image : baseUrl + row.default_car_image) : null
            },
            pickupCode: row.id,
            scheduledPickupTime: row.scheduled_pickup_time,
            orderNote: row.order_note,
            isGift: row.is_gift,
            recipientPhone: row.recipient_phone,
            giftMessage: row.gift_message
        }));

        res.json(orders);
    } catch (err) {
        console.error("Order fetch error:", err);
        res.status(500).json({ message: 'Server error: ' + err.message, detail: err.stack });
    }
});

router.get('/employee-view/:id', async (req, res) => {
    try {
        // Fetch Order + Customer Info
        const orderRes = await pool.query(`
            SELECT o.*, u.name as customer_name, u.phone as customer_phone, b.name as branch_name
            FROM orders o
            LEFT JOIN customers u ON o.customer_id = u.id
            LEFT JOIN branches b ON o.branch_id = b.id
            WHERE o.id = $1
        `, [req.params.id]);

        if (orderRes.rows.length === 0) return res.status(404).json({ message: 'Order not found' });

        const order = orderRes.rows[0];

        // Fetch Items
        const itemsRes = await pool.query(
            `SELECT oi.*, p.name, p.image_url 
             FROM order_items oi 
             LEFT JOIN products p ON oi.product_id = p.id 
             WHERE oi.order_id = $1`,
            [req.params.id]
        );

        // Construct Response matching App interface
        res.json({
            ...order,
            customer: {
                name: order.customer_name,
                phone: order.customer_phone
            },
            items: itemsRes.rows
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Employee Update Status (No Auth for LAN)
router.put('/employee-view/:id/status', async (req, res) => {
    const { status } = req.body;
    try {
        let query = 'UPDATE orders SET status = $1';
        const params = [status, req.params.id];

        if (status === 'ARRIVED') {
            query += ', arrived_at = NOW()';
        } else if (status === 'COMPLETED' || status === 'HANDOVER_COMPLETE') {
            // Capture completed_at and calculate interval
            query += ', completed_at = NOW(), handover_time = (NOW() - arrived_at)';
        }

        query += ' WHERE id = $2 RETURNING *';

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return res.status(404).json({ message: 'Order not found' });
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get All User Orders
router.get('/', verifyToken, async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM orders WHERE customer_id = $1 ORDER BY created_at DESC',
            [req.user.id]
        );
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get Frequent Items (My Usuals)
router.get('/usuals', verifyToken, async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT p.id, p.name, p.price, p.image_url, COUNT(oi.product_id) as freq
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.id
            WHERE o.customer_id = $1
            GROUP BY p.id, p.name, p.price, p.image_url
            ORDER BY freq DESC
            LIMIT 10
        `, [req.user.id]);

        // Ensure URLs are valid (match products.js logic if needed, but assuming DB is clean)
        // Similar to products.js logic if relative paths exist:
        const baseUrl = `${req.protocol}://${req.get('host')}/uploads/`;
        const items = result.rows.map(item => {
            if (item.image_url && !item.image_url.startsWith('http')) {
                item.image_url = baseUrl + item.image_url;
            }
            return item;
        });

        res.json(items);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get Order Status / Details
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const orderRes = await pool.query(`
            SELECT o.*, b.name as branch_name, b.map_pin, b.latitude, b.longitude, b.landmark_hint 
            FROM orders o
            LEFT JOIN branches b ON o.branch_id = b.id
            WHERE o.id = $1 AND o.customer_id = $2
        `, [req.params.id, req.user.id]);
        if (orderRes.rows.length === 0) return res.status(404).json({ message: 'Order not found' });

        const itemsRes = await pool.query(
            `SELECT oi.*, p.name, p.image_url 
             FROM order_items oi 
             LEFT JOIN products p ON oi.product_id = p.id 
             WHERE oi.order_id = $1`,
            [req.params.id]
        );

        res.json({ ...orderRes.rows[0], items: itemsRes.rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update Status
// Update Status (Customer or Recipient)
router.put('/:id/status', verifyToken, async (req, res) => {
    const { status } = req.body;
    try {
        // Fetch user phone to check if they are the recipient
        const userRes = await pool.query('SELECT phone FROM customers WHERE id = $1', [req.user.id]);
        const userPhone = userRes.rows[0]?.phone;

        let query = 'UPDATE orders SET status = $1';
        const params = [status, req.params.id, req.user.id, userPhone];

        if (status === 'ARRIVED') {
            query += ', arrived_at = NOW()';
        } else if (status === 'COMPLETED' || status === 'HANDOVER_COMPLETE') {
            query += ', completed_at = NOW(), handover_time = (NOW() - arrived_at)';
        }

        // Allow update if User is the Buyer (customer_id) OR the Recipient (recipient_phone)
        query += ' WHERE id = $2 AND (customer_id = $3 OR recipient_phone = $4) RETURNING *';

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return res.status(404).json({ message: 'Order not found or unauthorized' });
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Assign Gift Recipient
router.put('/:id/gift-assign', verifyToken, async (req, res) => {
    const { recipient_phone, gift_message } = req.body;
    try {
        const result = await pool.query(
            'UPDATE orders SET recipient_phone = $1, gift_message = $2, is_gift = true WHERE id = $3 AND customer_id = $4 RETURNING *',
            [recipient_phone, gift_message, req.params.id, req.user.id]
        );
        if (result.rows.length === 0) return res.status(404).json({ message: 'Order not found' });
        res.json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error assigning gift' });
    }
});

// Fetch My Received Gifts (Where I am the Recipient)
router.get('/my-received', verifyToken, async (req, res) => {
    try {
        // Fetch phone of logged-in user
        const userRes = await pool.query('SELECT phone FROM customers WHERE id = $1', [req.user.id]);
        if (userRes.rows.length === 0) return res.status(404).json({ message: 'User not found' });

        const phone = userRes.rows[0].phone;

        // Fetch orders where this user is the recipient
        const result = await pool.query(`
            SELECT o.*, b.name as branch_name, 
                   json_agg(json_build_object(
                       'name', p.name, 
                       'quantity', oi.quantity, 
                       'image_url', p.image_url
                   )) as items
            FROM orders o
            LEFT JOIN order_items oi ON o.id = oi.order_id
            LEFT JOIN products p ON oi.product_id = p.id
            LEFT JOIN branches b ON o.branch_id = b.id
            WHERE o.recipient_phone = $1 AND o.is_gift = true
            GROUP BY o.id, b.name
            ORDER BY o.created_at DESC
        `, [phone]);

        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error fetching gifts' });
    }
});

// Create Order (Checkout)
router.post('/', verifyToken, async (req, res) => {
    console.log("POST /api/orders Body:", req.body); // Debug Log

    const { branch_id, car_model, car_plate, car_color, scheduled_pickup_time, use_wallet, donation_amount } = req.body;

    // Robust extraction (Snake case vs Camel case)
    const is_gift = req.body.is_gift || req.body.isGift || false;
    const recipient_phone = req.body.recipient_phone || req.body.recipientPhone || null;
    const gift_message = req.body.gift_message || req.body.giftMessage || null;
    const vehicle_type = req.body.vehicle_type || req.body.vehicleType || 'private';
    const vehicle_plate = req.body.vehicle_plate || req.body.vehiclePlate || car_plate;
    const vehicle_color = req.body.vehicle_color || req.body.vehicleColor || car_color;

    const customer_id = req.user.id;

    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        // 1. Fetch Cart Items (Products AND Bundles)
        const cartRes = await client.query(
            `SELECT 
                c.*, 
                p.price as product_price, 
                b.price as bundle_price,
                b.branch_id as bundle_branch_id
             FROM cart_items c 
             LEFT JOIN products p ON c.product_id = p.id 
             LEFT JOIN bundles b ON c.bundle_id = b.id 
             WHERE c.customer_id = $1`,
            [customer_id]
        );

        if (cartRes.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: 'Cart is empty' });
        }

        // 2. Calculate Total & Find Branch
        let total_price = 0;
        let valid_branch_id = branch_id; // Default to request body
        const orderItems = [];

        for (const item of cartRes.rows) {
            // Determine price
            const price = Number(item.product_price || item.bundle_price || 0);
            total_price += price * item.quantity;

            // Prefer bundle's branch if available (auto-detection)
            if (item.bundle_branch_id) {
                valid_branch_id = item.bundle_branch_id;
            }

            orderItems.push({
                product_id: item.product_id, // can be null
                bundle_id: item.bundle_id,   // can be null
                quantity: item.quantity,
                price: price
            });
        }

        // Feature 42: Donation
        if (donation_amount && Number(donation_amount) > 0) {
            total_price += Number(donation_amount);
        }

        // Final fallback: check if valid_branch_id exists, if not get ANY branch
        // This prevents FK violation from frontend hardcoded dummy IDs
        const checkBranch = await client.query('SELECT id FROM branches WHERE id = $1', [valid_branch_id]);
        if (checkBranch.rows.length === 0) {
            const anyBranch = await client.query('SELECT id FROM branches LIMIT 1');
            if (anyBranch.rows.length > 0) {
                valid_branch_id = anyBranch.rows[0].id;
            }
        }

        // 3. Create Order       
        const orderRes = await client.query(
            `INSERT INTO orders (branch_id, customer_id, total_price, car_model, car_plate, car_color, status, scheduled_pickup_time, is_gift, recipient_phone, gift_message, vehicle_type, vehicle_plate, vehicle_color)
             VALUES ($1, $2, $3, $4, $5, $6, 'Pending', $7, $8, $9, $10, $11, $12, $13)
             RETURNING *`,
            [
                valid_branch_id, customer_id, total_price,
                car_model, car_plate, car_color,
                scheduled_pickup_time || null,
                is_gift,
                recipient_phone,
                gift_message,
                vehicle_type,
                vehicle_plate,
                vehicle_color
            ]
        );
        const orderID = orderRes.rows[0].id;

        // 4. Insert Order Items
        for (const item of orderItems) {
            await client.query(
                `INSERT INTO order_items (order_id, product_id, bundle_id, quantity, price_at_purchase)
                 VALUES ($1, $2, $3, $4, $5)`,
                [orderID, item.product_id, item.bundle_id, item.quantity, item.price]
            );
        }

        // 5. Clear Cart
        await client.query('DELETE FROM cart_items WHERE customer_id = $1', [customer_id]);

        // 6. Award Loyalty Points (1 Point per 100 ETB)
        const pointsEarned = Math.floor(total_price / 100);
        if (pointsEarned > 0) {
            await client.query(
                'UPDATE customers SET loyalty_points = COALESCE(loyalty_points, 0) + $1 WHERE id = $2',
                [pointsEarned, customer_id]
            );
        }

        // Feature 48: Split Pay / Wallet
        if (use_wallet === true) {
            const userRes = await client.query('SELECT wallet_balance FROM customers WHERE id = $1', [customer_id]);
            const balance = Number(userRes.rows[0].wallet_balance || 0);
            if (balance > 0) {
                const toDeduct = Math.min(balance, total_price);
                await client.query('UPDATE customers SET wallet_balance = wallet_balance - $1 WHERE id = $2', [toDeduct, customer_id]);
            }
        }

        await client.query('COMMIT');

        res.json({
            ...orderRes.rows[0],
            message: 'Order created successfully',
            points_earned: pointsEarned
        });

    } catch (err) {
        await client.query('ROLLBACK');
        console.error('Order creation failed:', err);
        res.status(500).json({ message: 'Failed to create order', error: err.message });
    } finally {
        client.release();
    }
});

module.exports = router;
