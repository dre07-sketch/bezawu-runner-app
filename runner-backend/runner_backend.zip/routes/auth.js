const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const { pool } = require('../middleware/authMiddleware');

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_key_change_this';

// 1. Customer Signup
console.log('Loading auth routes...');
router.post('/customer/signup', async (req, res) => {
    const { name, phone, password, car_plate, car_model, car_color } = req.body;

    if (!name || !phone || !password) {
        return res.status(400).json({ message: 'Name, Phone and Password are required' });
    }

    try {
        // Check if user exists
        const userCheck = await pool.query('SELECT id FROM customers WHERE phone = $1', [phone]);
        if (userCheck.rows.length > 0) {
            return res.status(400).json({ message: 'User with this phone already exists' });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);

        // Insert new user
        const result = await pool.query(
            `INSERT INTO customers (
                name, phone, password_hash, 
                default_car_plate, default_car_model, default_car_color
            ) VALUES ($1, $2, $3, $4, $5, $6) 
            RETURNING id, name, phone, default_car_plate, default_car_model, default_car_color`,
            [name, phone, hash, car_plate, car_model, car_color]
        );

        const customer = result.rows[0];
        const token = jwt.sign({ id: customer.id, role: 'customer' }, JWT_SECRET, { expiresIn: '30d' });

        res.status(201).json({ token, user: customer });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error during signup: ' + err.message });
    }
});

// 2. Customer Login
router.post('/customer/login', async (req, res) => {
    const { phone, password } = req.body;

    if (!phone || !password) {
        return res.status(400).json({ message: 'Phone and Password are required' });
    }

    try {
        const result = await pool.query('SELECT * FROM customers WHERE phone = $1', [phone]);
        const customer = result.rows[0];

        console.log('Login attempt for:', phone);
        console.log('User found:', customer ? customer.id : 'No');

        if (!customer) {
            return res.status(400).json({ message: 'Invalid credentials (User not found)' });
        }

        // Check if they have a password set (legacy users might not if we migrated)
        if (!customer.password_hash) {
            return res.status(400).json({ message: 'Please reset your password or contact support.' });
        }

        console.log('Comparing password:', password, 'with hash:', customer.password_hash ? 'Present' : 'Missing');
        const isMatch = await bcrypt.compare(password, customer.password_hash);
        console.log('Password match:', isMatch);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials (Password mismatch)' });
        }

        const token = jwt.sign({ id: customer.id, role: 'customer' }, JWT_SECRET, { expiresIn: '30d' });

        // Don't send password hash back
        delete customer.password_hash;

        res.json({ token, user: customer });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error: ' + err.message });
    }
});

// 3. Manager Login (unchanged, but could be unified logic)
// 3. Manager Login (unchanged)
router.post('/manager/login', async (req, res) => {
    // ... (existing code, not showing here to keep brief, but normally I would if replacing)
    // Minimizing diff context to just append
    const { email, password } = req.body;
    try {
        const result = await pool.query('SELECT * FROM managers WHERE email = $1', [email]);
        const manager = result.rows[0];
        if (!manager) return res.status(400).json({ message: 'Invalid credentials' });
        const isMatch = await bcrypt.compare(password, manager.password_hash);
        if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });
        const token = jwt.sign({ id: manager.id, branch_id: manager.branch_id, role: 'manager' }, JWT_SECRET, { expiresIn: '1d' });
        res.json({ token, user: { id: manager.id, name: manager.name, email: manager.email } });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// 4. Runner Login (ID only)
router.post('/runner/login', async (req, res) => {
    const { id } = req.body;

    if (!id) return res.status(400).json({ message: 'Runner ID is required' });

    try {
        // Fetch runner + branch name + supermarket name
        // Assuming joined tables. If name doesn't exist, we skip it.
        const result = await pool.query(`
            SELECT r.*,
                   b.name as branch_name, 
                   s.name as supermarket_name 
            FROM runners r
            LEFT JOIN branches b ON r.branch_id = b.id
            LEFT JOIN supermarkets s ON b.supermarket_id = s.id
            WHERE r.id = $1
        `, [id]);

        const runner = result.rows[0];

        if (!runner) {
            return res.status(404).json({ message: 'Runner ID not found' });
        }

        const token = jwt.sign({
            id: runner.id,
            role: 'runner',
            branch_id: runner.branch_id
        }, JWT_SECRET, { expiresIn: '365d' }); // Long expiry for runners

        res.json({
            token,
            user: {
                id: runner.id,
                role: 'runner',
                name: runner.full_name || runner.name || 'Runner', // Robust fallback
                branch_name: runner.branch_name,
                supermarket_name: runner.supermarket_name
            }
        });

    } catch (err) {
        console.error('Runner login error:', err);
        res.status(500).json({ message: 'Server error: ' + err.message });
    }
});

module.exports = router;
